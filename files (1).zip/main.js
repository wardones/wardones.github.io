/* wardone portfolio — interactions */

// Stagger hero reveals using data-delay
document.querySelectorAll(".reveal[data-delay]").forEach((el) => {
  el.style.setProperty("--d", el.dataset.delay);
});

// Scroll-triggered reveals for project cards
const io = new IntersectionObserver(
  (entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        io.unobserve(entry.target);
      }
    }
  },
  { threshold: 0.15, rootMargin: "0px 0px -80px 0px" }
);

document.querySelectorAll(".project").forEach((el) => io.observe(el));

// Current year
const yearEl = document.getElementById("year");
if (yearEl) yearEl.textContent = new Date().getFullYear();
